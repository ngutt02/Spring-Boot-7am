package com.pack.ems;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmsFormBasedSecurityDataBaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
