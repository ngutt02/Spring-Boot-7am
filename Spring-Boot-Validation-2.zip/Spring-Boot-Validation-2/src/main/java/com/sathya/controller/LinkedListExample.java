package com.sathya.controller;
import java.util.*;
public class LinkedListExample
{
public static void main(String[] args)
{
LinkedList<String> ll=new LinkedList<String>();
ll.add("Scott");
ll.add("Dennis");
ll.add("James");
ll.add("Goshling");
Iterator<String> itr=ll.iterator();
while(itr.hasNext())
{
System.out.println(itr.next());


}






}








}