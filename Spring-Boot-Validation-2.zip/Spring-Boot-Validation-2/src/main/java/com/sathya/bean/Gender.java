package com.sathya.bean;

public enum Gender {

	MALE,FEMALE,OTHERS
}
