package com.sathya;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootValidation2Application {

	public static void main(String[] args) {
		System.out.println("hiii");
		SpringApplication.run(SpringBootValidation2Application.class, args);
	}

}
