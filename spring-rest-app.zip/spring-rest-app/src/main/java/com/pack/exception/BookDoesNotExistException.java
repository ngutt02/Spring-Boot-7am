package com.pack.exception;

public class BookDoesNotExistException extends RuntimeException {

	
	
}
