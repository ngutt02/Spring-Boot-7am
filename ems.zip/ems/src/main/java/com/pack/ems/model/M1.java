package com.pack.ems.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
class Person {

	private Integer eno;
	private String ename;
	private Double esalary;
	
}

public class M1 {
	
	public static void main(String[] args) {
		Person person = new Person();
	}
	
}
